// Learn more: https://stackoverflow.com/questions/37521298/how-to-inject-document-in-angular-2-service

import { Injectable, Inject, RendererFactory2 } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Storage } from '@ionic/storage';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  renderer: any;

  constructor(@Inject(DOCUMENT) private document: Document, rendererFactory: RendererFactory2, private storage: Storage) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }

  addBodyClass(bodyClass) {
    this.renderer.addClass(this.document.body, bodyClass);
  }

  removeBodyClass(bodyClass) {
    this.renderer.removeClass(this.document.body, bodyClass);
  }

  toggleDarkTheme(isDark = true, needUpdate = true) {
    if (needUpdate) this.storage.set('darkMode', isDark);
    return isDark ? this.addBodyClass('dark-mode') : this.removeBodyClass('dark-mode');
  }

  getCurrentSetting() {
    return this.storage.get('darkMode');
  }

  restore() {
    this.storage.get('darkMode').then(val => {
      this.toggleDarkTheme(val, false);
    });
  }
}

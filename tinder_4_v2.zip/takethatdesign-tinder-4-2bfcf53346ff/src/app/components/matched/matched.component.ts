import { Component, OnInit } from '@angular/core';
import { NavParams, ModalController } from '@ionic/angular';

@Component({
  selector: 'matched',
  templateUrl: './matched.component.html',
  styleUrls: ['./matched.component.scss']
})
export class MatchedComponent implements OnInit {
  user: any;

  constructor(public navParams: NavParams, public modalCtrl: ModalController) {
    this.user = navParams.data.user;
  }

  ngOnInit() {
  }

  close() {
    this.modalCtrl.dismiss();
  }

}

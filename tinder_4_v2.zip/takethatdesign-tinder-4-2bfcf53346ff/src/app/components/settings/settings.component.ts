import { Component, OnInit } from '@angular/core';
import { ModalController, NavController } from '@ionic/angular';
import { ThemeService } from '../../services/theme/theme.service';

@Component({
  selector: 'settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
})
export class SettingsComponent implements OnInit {
  distance: number = 30;
  ageRange: any = {
    lower: 20,
    upper: 30
  };
  isDark: boolean;

  constructor(public modalCtrl: ModalController, private navCtrl: NavController, private themeService: ThemeService) {

  }

  ngOnInit() {
    this.themeService.getCurrentSetting()
      .then(val => {
        this.isDark = val;
      })
  }

  close() {
    this.modalCtrl.dismiss();
  }

  logout() {
    this.close();
    this.navCtrl.navigateBack('/landing');
  }

  toggleDarkTheme(isDark) {
    this.themeService.toggleDarkTheme(isDark);
  }

}

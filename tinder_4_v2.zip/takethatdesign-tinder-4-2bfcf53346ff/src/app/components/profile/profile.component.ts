import { Component, OnInit } from '@angular/core';
import { NavParams, ModalController } from '@ionic/angular';
import { StatusBar } from '@ionic-native/status-bar/ngx';

@Component({
  selector: 'profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  user: any;
  profileImages: any[] = [];

  constructor(public navParams: NavParams, public modalCtrl: ModalController, private statusBar: StatusBar) {
    this.user = navParams.data.user;
    this.statusBar.hide();
  }

  ngOnInit() {
    this.profileImages = [
      { imageUrl: 'assets/img/people/hieu.png' },
      { imageUrl: 'assets/img/people/thanos.png' },
      { imageUrl: 'assets/img/people/captain.png' },
      { imageUrl: 'assets/img/people/thor.png' },
    ]
  }

  ionViewWillLeave() {
    this.statusBar.show();
  }

  close() {
    this.modalCtrl.dismiss();
  }

}

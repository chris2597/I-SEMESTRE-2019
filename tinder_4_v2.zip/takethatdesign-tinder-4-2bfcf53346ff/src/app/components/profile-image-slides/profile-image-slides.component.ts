import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { IonSlides } from '@ionic/angular';

@Component({
  selector: 'profile-image-slides',
  templateUrl: './profile-image-slides.component.html',
  styleUrls: ['./profile-image-slides.component.scss']
})
export class ProfileImageSlidesComponent implements OnInit {
  activeIndex: number = 0;
  @Input() images: any[] = [];
  @ViewChild('profileImages') slides: IonSlides;

  constructor() {

  }

  ngOnInit() {
    
  }

  onSlideChange() {
    this.slides.getActiveIndex()
      .then(index => {
        this.activeIndex = index;
      })
  }

}

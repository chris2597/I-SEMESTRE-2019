import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plus-intro',
  templateUrl: './plus-intro.component.html',
  styleUrls: ['./plus-intro.component.scss']
})
export class PlusIntroComponent implements OnInit {
  slideOpts = {
    autoplay: true,
    delay: 3000
  };
  
  constructor() { }

  ngOnInit() {
  }

}

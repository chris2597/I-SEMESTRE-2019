import { Component, OnInit } from '@angular/core';
import { NavController, LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.page.html',
  styleUrls: ['./landing.page.scss'],
})
export class LandingPage implements OnInit {
  introSlides: any;

  constructor(private navCtrl: NavController, private loadingCtrl: LoadingController) { }

  ngOnInit() {
    this.introSlides = [
      {
        title: 'Discover new and interesting <br> people nearby',
        image: 'assets/img/intro/intro_1.png'
      },
      {
        title: 'Swipe Right to like someone <br /> or Swipe Left to pass',
        image: 'assets/img/intro/intro_2.png'
      },
      {
        title: 'If they also Swipe Right <br /> then "It\'s a Match!"',
        image: 'assets/img/intro/intro_3.png'
      },
      {
        title: 'Only people you\'ve matched <br /> with can message you',
        image: 'assets/img/intro/intro_4.png'
      }
    ]
  }

  async goToExplore() {
    const loading = await this.loadingCtrl.create({
      message: 'Logging In...',
      translucent: true
    });


    await loading.present();

    setTimeout(() => {
      loading.dismiss();
      this.navCtrl.navigateRoot('/explore');
    }, 1000);// dummy loader for Loggin In
  }

}

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { IonicStorageModule } from '@ionic/storage';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { MatchedComponent } from './components/matched/matched.component';
import { ProfileComponent } from './components/profile/profile.component';
import { ProfileImageSlidesComponent } from './components/profile-image-slides/profile-image-slides.component';
import { ProfileEditComponent } from './components/profile-edit/profile-edit.component';
import { SettingsComponent } from './components/settings/settings.component';

@NgModule({
  declarations: [
    AppComponent,
    MatchedComponent,
    ProfileComponent,
    ProfileImageSlidesComponent,
    ProfileEditComponent,
    SettingsComponent,
  ],
  entryComponents: [
    MatchedComponent,
    ProfileComponent,
    ProfileEditComponent,
    SettingsComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    IonicModule.forRoot({
      mode: 'ios',
      backButtonText: '',
    }),
    AppRoutingModule,
    IonicStorageModule.forRoot({
      name: 'tinder',
      driverOrder: ['indexeddb', 'sqlite', 'websql']
    }),
  ],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

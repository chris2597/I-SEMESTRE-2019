
/**
 * LABORATORIO #1 INDIVIDUAL
 * CHRISTOPHER JIMENEZ 8-922-2240
 * DS9
 */
(function () {
    var App = {
        Data: {
            array: undefined
        },
        Methods: {
            init: function (array) {

                App.Methods.overridePrototype();
                App.Data.array = array;

            },
            getAllSumArray: function () {
                var sum = 0;

                for (let index = 0; index < App.Data.array.length; index++) {
                    
                    if(App.Data.array[index] < 1 || App.Data.array[index] > 100){
                        throw new App.Exceptions.MathException('El número ingresado debe estar en el rango de 1 y 100');
                    } else{
                        sum = sum + App.Data.array[index];
                    }
                }

                return sum;
            },
            overridePrototype: function () {
                App.Exceptions.MathException.prototype.toString = App.Utils.toString;
            },
        },
        Exceptions: {
            MathException: function (message) {
                this.message = message;
                this.name = 'MathException';
            }
        },
        Utils: {
            toString: function () {
                return `${this.name}: ${this.message}`;
            },

        }
    }
    App.Methods.init([1, 2, 101]);
    console.log(App.Methods.getAllSumArray());
})()
/**
 * LABORATORIO #2 INDIVIDUAL
 * CHRISTOPHER JIMENEZ 8-922-2240
 * DS9
 */
(function () {

    var App = {

        Data: {
            matrix: undefined
        },
        Methods: {
            init: function (n) {

                App.Methods.overridePrototype();
                App.Data.matrix = new Array(n);

            },
            generateRandomNumbers: function () {

                for (let index = 0; index < App.Data.matrix.length; index++) {

                    App.Data.matrix[index] = new Array(App.Data.matrix.length); //define la longitud de cada fila

                    for (let sIndex = 0; sIndex < App.Data.matrix[index].length; sIndex++) {
                        App.Data.matrix[index][sIndex] = Math.floor(Math.random() * 10);
                    }
                }

                return App.Data.matrix;
            },
            sumPrincipalSlash: function () {

                var sumOfPrincipalSlash = 0;
                for (let index = 0; index < App.Data.matrix.length; index++) {
                    sumOfPrincipalSlash = sumOfPrincipalSlash + App.Data.matrix[index][index];
                }

                return sumOfPrincipalSlash;
            },
            overridePrototype: function () {
                App.Exceptions.MathException.prototype.toString = App.Utils.toString;
            },
            ThrowException1: function () {
                throw new App.Exceptions.MathException('');
            },
        },
        Exceptions: {
            MathException: function (message) {
                this.message = message;
                this.name = 'MathException';
            }
        },
        Utils: {
            toString: function () {
                return `${this.name}: ${this.message}`;
            },

        }
    };
    App.Methods.init(4);
    console.log("Dimensión de la Matriz: ", App.Data.matrix.length, " x ", App.Data.matrix.length);
    console.log("Matriz generada: ", App.Methods.generateRandomNumbers());
    console.log("Suma de la diagonal principal: ", App.Methods.sumPrincipalSlash());
})();
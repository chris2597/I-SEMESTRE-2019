/**
 * LABORATORIO #3 INDIVIDUAL
 * CHRISTOPHER JIMENEZ 8-922-2240
 * DS9
 */
(function () {

    var App = {

        Data: {
            array: undefined
        },
        Methods: {
            init: function (array) {

                App.Methods.overridePrototype();
                App.Data.array = array;

            },
            getPairOfArray: function () {

                var quantOfPair = 0;
                var array = App.Data.array;

                for (var index = 0; index < array.length; index++) {

                    for (var j = index; j < array.length; j++) {

                        if (array[index] == array[j + 1] && array[index] != null && array[j + 1] != null) {

                            quantOfPair++;
                            array[index] = null;
                            array[j + 1] = null;
                            break;
                        }

                    }
                }

                return quantOfPair;
            },
            overridePrototype: function () {
                App.Exceptions.MathException.prototype.toString = App.Utils.toString;
            },
            ThrowException1: function () {
                throw new App.Exceptions.MathException('');
            },
        },
        Exceptions: {
            MathException: function (message) {
                this.message = message;
                this.name = 'MathException';
            }
        },
        Utils: {
            toString: function () {
                return `${this.name}: ${this.message}`;
            },

        }
    };
    App.Methods.init([4, 5, 4, 5, 4, 5, 3, 3, 3, 3, 1]);
    console.log("Cantidad de Pares en el Array: ", App.Methods.getPairOfArray());
})();
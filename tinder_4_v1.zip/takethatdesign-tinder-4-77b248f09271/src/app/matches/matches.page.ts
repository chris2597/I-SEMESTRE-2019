import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-matches',
  templateUrl: './matches.page.html',
  styleUrls: ['./matches.page.scss'],
})
export class MatchesPage implements OnInit {
  segmentView = '0';
  feedItems: any[] = [
    { url: 'assets/img/avatars/hieu.png' },
    { url: 'assets/img/avatars/thor.png' },
    { url: 'assets/img/avatars/blackpanther.png' }
  ];

  constructor(private navCtrl: NavController) { }

  ngOnInit() {

  }

  goToExplore() {
    this.navCtrl.navigateBack('/explore');
  }

  goToChat() {
    this.navCtrl.navigateForward('/chat');
  }
}

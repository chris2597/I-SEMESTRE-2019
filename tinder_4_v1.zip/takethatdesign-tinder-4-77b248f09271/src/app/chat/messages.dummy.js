export default [
  {
    isSender: true,
    type: 'image',// text || image
    body: 'https://media.giphy.com/media/3oz8xSjBmD1ZyELqW4/giphy.gif',
    timestamp: 'Jan 25, 2019 9:47am'
  },
  {
    isSender: false,
    avatar: 'assets/img/avatars/hieu.png',
    type: 'text',// text || image
    body: 'Hey yo what\'s up?',
    timestamp: 'Jan 25, 2019 9:48am'
  },
  {
    isSender: true,
    type: 'image',// text || image
    body: 'https://media.giphy.com/media/lXiRyZVS9B79r2YOQ/giphy.gif',
    timestamp: 'Jan 25, 2019 9:50am'
  },
  {
    isSender: false,
    avatar: 'assets/img/avatars/hieu.png',
    type: 'image',// text || image
    body: 'https://media.giphy.com/media/JUMLTR3dHEGpW/giphy.gif',
    timestamp: 'Jan 25, 2019 9:52am'
  },
  {
    isSender: true,
    type: 'text',// text || image
    body: 'Where are you, buddy?',
    timestamp: 'Jan 25, 2019 9:53am'
  },
  {
    isSender: false,
    avatar: 'assets/img/avatars/hieu.png',
    type: 'text',// text || image
    body: 'I\'m almost there',
    timestamp: 'Jan 25, 2019 9:53am'
  }
];

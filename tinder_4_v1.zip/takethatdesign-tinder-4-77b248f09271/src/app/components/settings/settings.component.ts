import { Component, OnInit } from '@angular/core';
import { ModalController, NavController } from '@ionic/angular';

@Component({
  selector: 'settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
})
export class SettingsComponent implements OnInit {
  distance: number = 30;
  ageRange: any = {
    lower: 20,
    upper: 30
  };

  constructor(public modalCtrl: ModalController, private navCtrl: NavController) {

  }

  ngOnInit() {}

  close() {
    this.modalCtrl.dismiss();
  }

  logout() {
    this.close();
    this.navCtrl.navigateBack('/landing');
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { RandomAvatarComponent } from './random-avatar/random-avatar.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
  ],
  declarations: [
    RandomAvatarComponent,
  ],
  providers: [],
  exports: [
    RandomAvatarComponent
  ]
})

export class SharedModule {}

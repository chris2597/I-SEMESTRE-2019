import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'profile-edit',
  templateUrl: './profile-edit.component.html',
  styleUrls: ['./profile-edit.component.scss'],
})
export class ProfileEditComponent implements OnInit {
  aboutMe: string = `I'm obsessed with building mobile apps with Ionic Framework. What about you?`;
  constructor(public modalCtrl: ModalController) {

  }

  ngOnInit() {}

  close() {
    this.modalCtrl.dismiss();
  }

}

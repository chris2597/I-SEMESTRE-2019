import { Component, OnInit } from '@angular/core';
import { NavController, ModalController } from '@ionic/angular';
import { ProfileComponent } from '../components/profile/profile.component';
import { SettingsComponent } from '../components/settings/settings.component';
import { ProfileEditComponent } from '../components/profile-edit/profile-edit.component';

@Component({
  selector: 'app-me',
  templateUrl: './me.page.html',
  styleUrls: ['./me.page.scss'],
})
export class MePage implements OnInit {

  constructor(private navCtrl: NavController, private modalCtrl: ModalController) { }

  ngOnInit() {

  }

  goToExplore() {
    this.navCtrl.navigateForward('/explore');
  }

  async viewProfile() {
    const user = {
      id: 1,
      name: 'Hieu Pham',
      age: 29,
      job_title: 'UX/UI lover',
      profile_image_url: 'assets/img/avatars/hieu.png'
    };

    const modal = await this.modalCtrl.create({
      component: ProfileComponent,
      componentProps: {
        user: user
      }
    });
    return await modal.present();
  }

  async viewSettings() {
    const modal = await this.modalCtrl.create({
      component: SettingsComponent
    });
    return await modal.present();
  }

  async viewEditProfile() {
    const modal = await this.modalCtrl.create({
      component: ProfileEditComponent
    });
    return await modal.present();
  }

}
